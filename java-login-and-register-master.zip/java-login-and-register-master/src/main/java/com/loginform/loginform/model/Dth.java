package com.loginform.loginform.model;




import java.util.Objects;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Dth {

 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private Integer id;

 private String customMessage;

 // Getters and Setters

 public Integer getId() {
     return id;
 }

 public void setId(Integer id) {
     this.id = id;
 }

 public String getCustomMessage() {
     return customMessage;
 }

 public void setCustomMessage(String customMessage) {
     this.customMessage = customMessage;
 }
 @Override
 public boolean equals(Object o) {
     if (this == o) return true;
     if (o == null || getClass() != o.getClass()) return false;
     Dth dth = (Dth) o;
     return Objects.equals(id, dth.id) &&
            Objects.equals(customMessage, dth.customMessage);
 }

 @Override
 public int hashCode() {
     return Objects.hash(id, customMessage);
 }

 @Override
 public String toString() {
     return "Dth{" +
             "id=" + id +
             ", customMessage='" + customMessage + '\'' +
             '}';
 }
}
