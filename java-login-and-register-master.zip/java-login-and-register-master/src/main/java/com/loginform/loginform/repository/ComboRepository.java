package com.loginform.loginform.repository;



import com.loginform.loginform.model.ComboData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ComboRepository extends JpaRepository<ComboData, Integer> {
    // JpaRepository includes the findAll() method
}
