package com.loginform.loginform.controller;



import com.loginform.loginform.service.ComboService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller

public class ComboController {

    @Autowired
    private ComboService comboService;
    @GetMapping("/combo")
    public String getComboList(Model model) {
        model.addAttribute("combo", comboService.findAll());
        return "combo";
    }
    @PostMapping("/submitCombo")
    public String submitCombo(@RequestParam(name = "combo", required = false) String[] combos, Model model) {
        if (combos != null && combos.length > 0) {
            int totalAmount = comboService.calculateTotalAmount(combos);
            comboService.saveComboData(combos, totalAmount);
            model.addAttribute("totalAmount", totalAmount);
            return "submitCombo"; // Ensure this matches your view name
        } else {
            model.addAttribute("totalAmount", 0);
            return "submitCombo"; // Ensure this matches your view name
        }
    }

}

