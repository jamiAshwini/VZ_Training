package com.loginform.loginform.model;



import java.util.Objects;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "combo_table")
public class ComboData {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String comboChosen;
    private Integer totalAmount;
    public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getComboChosen() {
		return comboChosen;
	}

	public void setComboChosen(String comboChosen) {
		this.comboChosen = comboChosen;
	}

	public Integer getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Integer totalAmount) {
		this.totalAmount = totalAmount;
	}

	 @Override
	    public boolean equals(Object o) {
	        if (this == o) return true;
	        if (o == null || getClass() != o.getClass()) return false;
	        ComboData comboData = (ComboData) o;
	        return Objects.equals(id, comboData.id) &&
	               Objects.equals(comboChosen, comboData.comboChosen) &&
	               Objects.equals(totalAmount, comboData.totalAmount);
	    }
	 @Override
	    public int hashCode() {
	        return Objects.hash(id, comboChosen, totalAmount);
	    }
    // Constructors, getters, and setters
    public ComboData() {}

    public ComboData(String comboChosen, Integer totalAmount) {
        this.comboChosen = comboChosen;
        this.totalAmount = totalAmount;
    }

    // Getters and setters
}
