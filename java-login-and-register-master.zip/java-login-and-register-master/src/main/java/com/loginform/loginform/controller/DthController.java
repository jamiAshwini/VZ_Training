package com.loginform.loginform.controller;


import com.loginform.loginform.model.Dth;
import com.loginform.loginform.service.DthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Controller
public class DthController {

 @Autowired
 private DthService dthService;

 @GetMapping("/dth")
 public String getDthList(Model model) {
     model.addAttribute("dths", dthService.findAll());
     return "dth-list";
 }

 @GetMapping("/dth/add")
 public String addDthForm(Model model) {
     model.addAttribute("dth", new Dth());
     return "dth-form";
 }

 @PostMapping("/dth/add")
 public String addDth(@ModelAttribute Dth dth) {
     dthService.save(dth);
     return "redirect:/dth";
 }

 @GetMapping("/dth/edit/{id}")
 public String editDthForm(@PathVariable Integer id, Model model) {
     Optional<Dth> dth = dthService.findById(id);
     if (dth.isPresent()) {
         model.addAttribute("dth", dth.get());
         return "dth-form";
     }
     return "redirect:/dth";
 }

 @PostMapping("/dth/edit")
 public String updateDth(@ModelAttribute Dth dth) {
     dthService.save(dth);
     return "redirect:/dth";
 }

 @GetMapping("/dth/delete/{id}")
 public String deleteDth(@PathVariable Integer id) {
     dthService.deleteById(id);
     return "redirect:/dth";
 }
}
