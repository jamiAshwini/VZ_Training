package com.loginform.loginform.service;





import com.loginform.loginform.model.Call;
import com.loginform.loginform.repository.CallRepository;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class CallService {

    private final CallRepository callRepository;

    public CallService(CallRepository callRepository) {
        this.callRepository = callRepository;
    }

    public void saveCall(Call call) {
        callRepository.save(call);
    }
    public List<Call> getAllCalls() {
        return callRepository.findAll();
    }
}
