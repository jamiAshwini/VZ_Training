package com.loginform.loginform.repository;



import com.loginform.loginform.model.Dth;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DthRepository extends JpaRepository<Dth, Integer> {
}
