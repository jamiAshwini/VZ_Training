package com.loginform.loginform.service;




import com.loginform.loginform.model.Dth;
import com.loginform.loginform.repository.DthRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DthService {

 @Autowired
 private DthRepository dthRepository;

 public List<Dth> findAll() {
     return dthRepository.findAll();
 }

 public Optional<Dth> findById(Integer id) {
     return dthRepository.findById(id);
 }

 public Dth save(Dth dth) {
     return dthRepository.save(dth);
 }

 public void deleteById(Integer id) {
     dthRepository.deleteById(id);
 }
}
