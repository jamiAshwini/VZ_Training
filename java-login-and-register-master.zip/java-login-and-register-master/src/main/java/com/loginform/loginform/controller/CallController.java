package com.loginform.loginform.controller;

import com.loginform.loginform.model.Call;
import com.loginform.loginform.service.CallService;



import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CallController {

    private final CallService callService;

    public CallController(CallService callService) {
        this.callService = callService;
    }

    @RequestMapping("/add-call")
    public String addCallForm() {
        return "calls"; // Name of the HTML file for the form
    }

    @PostMapping("/add-call")
    public String addCall(@RequestParam("callTo") String callTo,
                          @RequestParam("duration") int duration,
                          @RequestParam("type") String type,
                          ModelMap model) {
        Call call = new Call();
        call.setCallTo(callTo);
        call.setDuration(duration);
        call.setType(type);
        callService.saveCall(call);

        model.addAttribute("calls", callService.getAllCalls()); // Update the list after adding a call
        return "calls"; // Return to the same template with updated call list
    }

}
