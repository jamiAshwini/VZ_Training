package com.loginform.loginform.controller;

import ch.qos.logback.core.model.Model;

import com.loginform.loginform.model.UsersModel;
import com.loginform.loginform.service.UsersService;

import org.springframework.ui.ModelMap;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
@Controller
public class UsersController {

    private final UsersService usersService;

    public UsersController(UsersService usersService) {
        this.usersService = usersService;
    }

    @GetMapping("/register")
    public String getRegisterPage(Model model){
        model.addText("registerRequest");
        return "register_page";
    }
    @GetMapping("/ott")
    public String getottPage(Model model){
        model.addText("ottRequest");
        return "ott";
    }
    @GetMapping("/Recharge history")
    public String getRechargePage(Model model){
        model.addText("rechargeRequest");
        return "Recharge history";
    }
    @GetMapping("/Payment history")
    public String getPaymentPage(Model model){
        model.addText("paymentRequest");
        return "Payment history";
    }

    @GetMapping("/login")
    public String getLoginPage(Model model){
        model.addText("loginRequest");
        return "login_page";
    }
    @GetMapping("/help")
    public String getHelpPage(Model model){
        model.addText("helpRequest");
        return "help";
    }
    @GetMapping("/rewards")
    public String getRewardsPage(Model model){
        model.addText("RewardsRequest");
        return "rewards";
    }
    @GetMapping("/coupon")
    public String getCouponPage(Model model){
        model.addText("CouponRequest");
        return "coupon";
    }

    @PostMapping("/register")
    public String register(@ModelAttribute UsersModel usersModel){
        System.out.println("register request : " + usersModel);
        UsersModel registeredUser= usersService.registerUser(usersModel.getLogin(),usersModel.getPassword(),usersModel.getEmail());
        return registeredUser==null?"error_page" : "redirect:/login";
    }

    @PostMapping("/login")
    public String register(@ModelAttribute UsersModel usersModel,Model model){
        System.out.println("login request : " + usersModel);
        UsersModel authenticated= usersService.authenticate(usersModel.getLogin(),usersModel.getPassword());
        if(authenticated!=null){
            model.addText("userLogin");
            return "personal_page";
        }else{
            return "error_page";
        }
    }
    @GetMapping("/home")
    public String getHomePage(Model model){
        model.addText("HomeRequest");
        return "home";
    }
    @GetMapping("/user-form")
    public String getUserForm() {
        return "user_form"; // Name of the HTML template for the form
    }
    @GetMapping("/user-details")
    public String getUserDetails(@RequestParam("username") String username, ModelMap model) {
        UsersModel user = usersService.findByUsername(username);
        if (user != null) {
            model.addAttribute("user", user);
            return "user_details"; // Name of the HTML view to display user details
        } else {
            model.addAttribute("error", "User not found");
            return "error_page"; // Name of the HTML view to display an error
        }
    }
    @GetMapping("/shop")
    public String getShopPage(Model model){
        model.addText("ShopRequest");
        return "shop";
    }


}
