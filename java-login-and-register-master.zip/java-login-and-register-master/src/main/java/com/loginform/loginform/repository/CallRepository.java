package com.loginform.loginform.repository;



import com.loginform.loginform.model.Call;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CallRepository extends JpaRepository<Call, Long> {
}
