package com.loginform.loginform.service;

import com.loginform.loginform.model.ComboData;
import com.loginform.loginform.repository.ComboRepository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ComboService {

    @Autowired
    private ComboRepository comboRepository;
    public List<ComboData> getAllComboData() {
        return comboRepository.findAll();
    }
    public int calculateTotalAmount(String[] combos) {
        int totalAmount = 0;
        for (String combo : combos) {
            switch (combo) {
                case "dth":
                case "wifi":
                    totalAmount += 1000;
                    break;
                case "entertainment":
                    totalAmount += 6000;
                    break;
            }
        }
        return totalAmount;
    }

    public void saveComboData(String[] combos, int totalAmount) {
        String comboChosen = String.join(",", combos);
        comboRepository.save(new ComboData(comboChosen, totalAmount));
    }
    public List<ComboData> findAll() {
        return comboRepository.findAll();
    }
   
}
